﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DarkWizard dark = new DarkWizard("Emo", 56);
            System.Console.WriteLine(dark);
        }
    }
}
﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            FamilyCar familyCar = new FamilyCar(150, 50);
            System.Console.WriteLine(familyCar);
        }
    }
}

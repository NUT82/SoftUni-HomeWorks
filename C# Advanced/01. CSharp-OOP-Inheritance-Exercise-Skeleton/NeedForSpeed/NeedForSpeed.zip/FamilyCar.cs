﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class FamilyCar : Car
    {
        public FamilyCar(int horsePower, int fuel)
            : base(horsePower, fuel)
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IRobot
    {
        public string Name { get; set; }
    }
}

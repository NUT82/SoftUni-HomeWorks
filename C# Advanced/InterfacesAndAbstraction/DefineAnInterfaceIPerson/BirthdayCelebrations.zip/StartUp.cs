﻿using DefineAnInterfaceIPerson;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBirthable> birthables = new List<IBirthable>();
            string text = Console.ReadLine();

            while (text != "End")
            {
                string[] split = text.Split();
                switch (split[0])
                {
                    case "Citizen":
                        Citizen citizen = new Citizen(split[1], int.Parse(split[2]), split[3], split[4]);
                        birthables.Add(citizen);
                        break;
                    case "Pet":
                        Pet pet = new Pet(split[1], split[2]);
                        birthables.Add(pet);
                        break;
                    default:
                        break;
                }

                text = Console.ReadLine();
            }

            string year = Console.ReadLine();

            Console.WriteLine(string.Join(Environment.NewLine, birthables.Where(e => e.Birthdate.EndsWith(year)).Select(i => i.Birthdate)));
        }
    }
}

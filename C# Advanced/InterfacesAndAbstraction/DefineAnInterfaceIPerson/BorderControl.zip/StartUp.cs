﻿using DefineAnInterfaceIPerson;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> cityEnters = new List<IIdentifiable>();
            string text = Console.ReadLine();

            while (text != "End")
            {
                string[] split = text.Split();
                if (split.Length == 3)
                {
                    Citizen citizen = new Citizen(split[0], int.Parse(split[1]), split[2]);
                    cityEnters.Add(citizen);
                }
                else
                {
                    Robot robot = new Robot(split[0], split[1]);
                    cityEnters.Add(robot);
                }

                text = Console.ReadLine();
            }

            string detainedId = Console.ReadLine();

            Console.WriteLine(string.Join(Environment.NewLine, cityEnters.Where(e => e.Id.EndsWith(detainedId)).Select(i => i.Id)));
        }
    }
}

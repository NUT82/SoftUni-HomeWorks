﻿using Vehicles.Contracts;

namespace Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const bool isSummer = true;
        
        public Truck(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            if (isSummer)
            {
                FuelConsumption += 1.6;
            }
        }

        public override void Refuel(double fuelAmount)
        {
            base.Refuel(fuelAmount * 0.95);
        }
    }
    
}

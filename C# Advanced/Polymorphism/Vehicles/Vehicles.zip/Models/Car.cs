﻿using Vehicles.Contracts;

namespace Vehicles.Models
{
    public class Car : Vehicle
    {
        private const bool isSummer = true;
        public Car(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {
            if (isSummer)
            {
                FuelConsumption += 0.9;
            }
        }
    }
}

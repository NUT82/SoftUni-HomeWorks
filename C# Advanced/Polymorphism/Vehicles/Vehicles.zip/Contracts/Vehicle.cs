﻿namespace Vehicles.Contracts
{
    public abstract class Vehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }

        public double FuelConsumption { get; protected set; } //litters per km

        public string Drive(double distance)
        {
            if (FuelConsumption * distance > FuelQuantity)
            {
                return $"{GetType().Name} needs refueling";
            }

            FuelQuantity -= FuelConsumption * distance;
            return $"{GetType().Name} travelled {distance} km";
        }

        public virtual void Refuel(double fuelAmount)
        {
            FuelQuantity += fuelAmount;
        }
    }
}

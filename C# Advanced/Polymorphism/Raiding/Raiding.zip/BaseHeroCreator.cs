﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    abstract class BaseHeroCreator
    {
        public abstract BaseHero GetBaseHero();
    }
}

﻿using WildFarm.Contracts;

namespace WildFarm.Models
{
    class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}

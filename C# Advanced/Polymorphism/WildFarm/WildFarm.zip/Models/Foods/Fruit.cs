﻿using WildFarm.Contracts;

namespace WildFarm.Models.Foods
{
    class Fruit : Food
    {
        public Fruit(int quantity)
            : base(quantity)
        {
        }
    }
}

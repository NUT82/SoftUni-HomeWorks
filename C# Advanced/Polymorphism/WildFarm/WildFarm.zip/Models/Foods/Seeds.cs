﻿using WildFarm.Contracts;

namespace WildFarm.Models
{
    class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}

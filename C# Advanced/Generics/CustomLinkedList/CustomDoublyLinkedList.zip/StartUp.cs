﻿using System;

namespace DoublyLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}

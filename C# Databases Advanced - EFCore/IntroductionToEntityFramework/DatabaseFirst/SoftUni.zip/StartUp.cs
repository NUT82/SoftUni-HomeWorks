﻿using SoftUni.Data;
using System;
using System.Linq;

namespace SoftUni
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var db = new SoftUniContext();
            var namesOfTownsStartsN = db.Towns
                .Where(t => t.Name.StartsWith("S"))
                .Select(t => t.Name)
                .ToList();
            Console.WriteLine(string.Join(Environment.NewLine, namesOfTownsStartsN));
        }
    }
}

﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;
using SoftUni.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Globalization;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(GetAddressesByTown(db));
        }

        public static string GetAddressesByTown(SoftUniContext context)
        {
            var addresses = context.Addresses
                .Select(a => new { a.AddressText, Count = a.Employees.Count(), TownName = a.Town.Name })
                .OrderByDescending(a => a.Count)
                .ThenBy(a => a.TownName)
                .ThenBy(a => a.AddressText)
                .Take(10)
                .ToArray();

            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in addresses)
            {
                stringBuilder.AppendLine($"{item.AddressText}, {item.TownName} - {item.Count} employees");
            }

            return stringBuilder.ToString();
        }

        /*
        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            var employeesWithProject = context.Employees
                //.Include(x => x.EmployeesProjects)
                //.ThenInclude(x => x.Project)
                .Where(e => e.EmployeesProjects.Any(p => p.Project.StartDate.Year >= 2001 && p.Project.StartDate.Year <= 2003))
                .Select(e => new { e.FirstName, e.LastName, ManagerFirstName = e.Manager.FirstName, ManagerLastName = e.Manager.LastName, Projects = e.EmployeesProjects.Select(p => new { ProjectName = p.Project.Name, ProjectStartDate = p.Project.StartDate, ProjectEndDate = p.Project.EndDate })})
                .Take(10)
                .ToArray();

            StringBuilder stringBuilder = new StringBuilder();
            foreach (var employee in employeesWithProject)
            {
                stringBuilder.AppendLine($"{employee.FirstName } {employee.LastName} - Manager: {employee.ManagerFirstName} {employee.ManagerLastName}");
                string endDate = "not finished";
                
                foreach (var project in employee.Projects)
                {
                    if (project.ProjectEndDate != null)
                    {
                        endDate = $"{project.ProjectEndDate.Value.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)}";
                    }
                    stringBuilder.AppendLine($"--{project.ProjectName} - {project.ProjectStartDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)} - {endDate}");
                }
            }

            return stringBuilder.ToString();
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            context.Employees
                .Where(e => e.LastName == "Nakov")
                .FirstOrDefault()
                .Address = new Address() { AddressText = "Vitoshka 15", TownId = 4 };
            context.SaveChanges();

            var info = context.Employees
                .Select(e => new { AT = e.Address.AddressText, e.AddressId })
                .OrderByDescending(e => e.AddressId)
                .Take(10)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.AT}");
            }

            return stringBuilder.ToString();

        }

        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var info = context.Employees
                .Select(e => new { e.FirstName, e.MiddleName, e.LastName, e.JobTitle, e.Salary, e.EmployeeId })
                .OrderBy(e => e.EmployeeId)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} {item.LastName} {item.MiddleName} {item.JobTitle} {item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var info = context.Employees
                .Select(e => new { e.FirstName, e.Salary })
                .Where(e => e.Salary > 50000)
                .OrderBy(e => e.FirstName)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} - {item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var info = context.Employees
                .Where(e => e.Department.Name == "Research and Development")
                .Select(e => new { e.FirstName, e.LastName, DN = e.Department.Name, e.Salary })
                .OrderBy(e => e.Salary)
                .ThenByDescending(e => e.FirstName)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} {item.LastName} from {item.DN} - ${item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        */
    }
}

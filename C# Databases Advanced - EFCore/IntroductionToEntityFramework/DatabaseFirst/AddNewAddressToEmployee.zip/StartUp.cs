﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var db = new SoftUniContext();
            Console.WriteLine(AddNewAddressToEmployee(db));
        }

        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            context.Employees
                .Where(e => e.LastName == "Nakov")
                .FirstOrDefault()
                .Address = new Address() { AddressText = "Vitoshka 15", TownId = 4 };
            context.SaveChanges();

            var info = context.Employees
                .Select(e => new { AT = e.Address.AddressText, e.AddressId })
                .OrderByDescending(e => e.AddressId)
                .Take(10)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.AT}");
            }

            return stringBuilder.ToString();

        }

        /*
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            var info = context.Employees
                .Select(e => new { e.FirstName, e.MiddleName, e.LastName, e.JobTitle, e.Salary, e.EmployeeId })
                .OrderBy(e => e.EmployeeId)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} {item.LastName} {item.MiddleName} {item.JobTitle} {item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            var info = context.Employees
                .Select(e => new { e.FirstName, e.Salary })
                .Where(e => e.Salary > 50000)
                .OrderBy(e => e.FirstName)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} - {item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            var info = context.Employees
                .Where(e => e.Department.Name == "Research and Development")
                .Select(e => new { e.FirstName, e.LastName, DN = e.Department.Name, e.Salary })
                .OrderBy(e => e.Salary)
                .ThenByDescending(e => e.FirstName)
                .ToArray();
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var item in info)
            {
                stringBuilder.AppendLine($"{item.FirstName} {item.LastName} from {item.DN} - ${item.Salary:F2}");
            }

            return stringBuilder.ToString();
        }

        */
    }
}

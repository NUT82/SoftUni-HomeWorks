﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data.Models.Enums
{
    public enum Genre
    {
        Blues = 1,
        Rap = 2,
        PopMusic = 3,
        Rock = 4,
        Jazz = 5
    }
}

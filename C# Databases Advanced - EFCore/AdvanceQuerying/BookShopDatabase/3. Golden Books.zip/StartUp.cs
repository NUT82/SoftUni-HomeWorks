﻿using BookShop.Data;
using BookShop.Models.Enums;
using System;
using System.Linq;

namespace BookShop
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            BookShopContext context = new BookShopContext();
            //string command = Console.ReadLine();

            //Console.WriteLine(GetBooksByAgeRestriction(context, command));
            Console.WriteLine(GetGoldenBooks(context));
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            if (Enum.TryParse(command, true, out AgeRestriction ageRestriction))
            {
                string[] titles = context.Books
                                    .Where(r => r.AgeRestriction == ageRestriction)
                                    .Select(b => b.Title)
                                    .OrderBy(t => t)
                                    .ToArray();

                return string.Join(Environment.NewLine, titles);
            }

            return $"{command} is not valid restriction!";
        }

        public static string GetGoldenBooks(BookShopContext context)
        {
            string[] titles = context.Books
                                    .Where(b => b.EditionType == EditionType.Gold && b.Copies < 5000)
                                    .OrderBy(i => i.BookId)
                                    .Select(b => b.Title)
                                    .ToArray();

            return string.Join(Environment.NewLine, titles);
        }
    }
}

﻿namespace BookShop.Models.Enums
{
    public enum AgeRestriction
    {
        Minor,
        Teen,
        Adult,
    }
}
